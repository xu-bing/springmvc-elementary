CREATE FUNCTION fn_dept_sal
      RETURN NUMBER
IS 


BEGIN
  RETURN NULL;
  

END fn_dept_sal;
/
